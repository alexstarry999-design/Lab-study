SCIENCE STUDY — ANDROID APK BUILD

This package wraps the supplied HTML/CSS/JavaScript app using Capacitor. It is prepared for a cloud build; it is not itself a compiled APK.

PHONE-FRIENDLY BUILD USING GITHUB:
1. Sign in at https://github.com in your browser and create a new repository.
2. Upload the CONTENTS of this ZIP (including package.json, capacitor.config.json, www folder, and .github folder) to the repository's main branch.
3. Open the repository's Actions tab. If prompted, enable GitHub Actions.
4. Select “Build Science Study APK” in the workflows list, tap “Run workflow”, then confirm.
5. Wait for the workflow to finish successfully. Open its completed run and find Artifacts near the bottom.
6. Download “Science-Study-debug-apk” and extract it. Install app-debug.apk on your Android phone. If Android prompts, allow your browser/files app to install unknown apps.

The debug APK is for personal testing/sideloading. Publishing on Google Play requires a properly signed release build and store compliance.

AI TUTOR NOTE:
The supplied ai-config.js is included unchanged. If the AI tutor depends on an API key or external backend, configure it securely before distributing the app. Do not embed a private API key in client-side JavaScript.
